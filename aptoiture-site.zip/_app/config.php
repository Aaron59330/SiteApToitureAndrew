<?php
define('SETUP_KEY', '9DB32A6E');
define('SITE_URL', 'https://aptoiture.eu');
define('MAIL_TO', 'apcouvreur@gmail.com');
define('MAIL_DOMAIN', 'aptoiture.eu');
